#!/bin/bash
#Implementation done in python3

argc="$#"

if [ $argc -eq 2 ]
then
	python3 20171151_1.py $1 $2 > 20171151_1.txt
else
	python3 20171151_2.py $1 > 20171151_2.txt
fi

