import sys
import os
import pickle

value_order = list()
opr_math = ['+', '-', '/', '*']
opr_rwo = ["READ", "WRITE", "OUTPUT"]
var_reed = list()
var_temp = dict()

def printValue(value_deta):
    for value in value_order:
        ln = len(value_order)
        if value in value_deta:
            str_value = str(value_deta[value])
            print(value, str_value , end='')
            if value_order.index(value) != ln - 1:
                print(" ", end='')
    print()

def getValue(deta):
    value_deta = dict()
    junk_deta = list()
    new_deta = list()
    deta = deta.strip().split()
    new_deta.append(deta)
    for index in range(0, len(deta), 2):
        junk_deta.append(deta)
        value_order.append(deta[index])
        value_deta[deta[index]] = int(deta[index + 1])
        junk_deta.append(value_deta)
        new_deta.append(deta[index])
    return value_deta


def rwoOpera(params, operation, swap_memb, value_deta, transaction_id):
    back_log = list()
    params = params.strip()
    delimiter = ","
    back_log.append(params)
    if delimiter in params:
        param1, param2 = params.split(",")
        param2 = param2.strip()
        back_log.append(param1)
        param1 = param1.strip()
        back_log.append(param2)
    if operation == "WRITE":
        print("<" + transaction_id + ", " + param1 + ", " + str(swap_memb[param1]) + ">")
        back_log.append(param1)
        swap_memb[param1] = var_temp[param2]
        back_log.append(param2)
        printValue(swap_memb)
        printValue(value_deta)
    elif operation == "OUTPUT":
    	value_deta[params] = swap_memb[params]
    elif operation == "READ":
        if param1 not in var_reed:
            swap_memb[param1] = value_deta[param1]
            back_log.append(param1)
            var_reed.append(param1)
        var_temp[param2] = swap_memb[param1]
    else:
        pass
    return swap_memb, value_deta

def computtValees(op1, operator, const_val, op):
    check_list = list()
    if op1.isdigit() == True:
        op1_value = int(op1)
    else:
        op1_value = var_temp[op1]
    if operator == '-':
        var_temp[op] = op1_value - const_val
        check_list.append("Subtraction Done!")
    elif operator == '*':
        var_temp[op] = op1_value * const_val
        check_list.append("Multiplication Done!")
    elif operator == '+':
        var_temp[op] = op1_value + const_val
        check_list.append("Addition Done!")
    elif operator == '/':
        if const_val != 0:
            var_temp[op] = op1_value / const_val
            check_list.append("Division Done!")
        else:
            print("Operation Error : Divide by Zero!")
            sys.exit(0)
    else:
        print("Invalid Operator used!")
    return var_temp


def executedeta(command, swap_memb, value_deta, transaction_id):
    db_flag = False
    exec_done = list()
    for operation in opr_rwo:
    	if operation in command:
            cmd = command.strip().split("(")[1].strip().split(")")[0]
            swap_memb, value_deta = rwoOpera(cmd, operation, swap_memb, value_deta, transaction_id)
            exec_done.append(swap_memb)
            db_flag = True
    if not db_flag:
        command = command.strip().split(":=")
        op = command[0].strip()
        exec_done.append(command)
        for operator in opr_math:
            if operator in command[1]:
                exec_done.append(operator)
                op1, const_val = command[1].strip().split(operator)
                op1 = op1.strip()
                exec_done.append(const_val)
                const_val = int(const_val.strip())
                var_temp = computtValees(op1, operator, const_val, op)
                exec_done.append(var_temp)
    exec_done = list()
    return swap_memb

def chekkTransDup(transaction_id, traans_order, commnd):
    if transaction_id not in traans_order:
        traans_order.append(transaction_id)
        commnd[transaction_id] = []
        return traans_order, commnd
                
    else:
        print("Duplicate Transactions")
        sys.exit(0)

def undoLog(filename, batch):
    file = open(filename)
    deta = file.readlines()
    file.close()
    line_numb = 1 -1
    value_deta = getValue(deta[line_numb])
    line_numb = 2 -1
    commnd = dict()
    traans_order = list()
    while line_numb < len(deta):
        if deta[line_numb].strip() != "":
            transaction_id, num_commnd = deta[line_numb].strip().split()
            traans_order, commnd = chekkTransDup(transaction_id, traans_order, commnd)
            num_commnd = int(num_commnd)
            while num_commnd > 0:
                line_numb = line_numb + 1
                commnd[transaction_id].append(deta[line_numb][:-1])
                num_commnd = num_commnd - 1
        line_numb += 1

    regstr = dict()
    swap_memb = dict()
    swap_l = list()
    shut_flag = dict()
    for trr in commnd:
        swap_l.append(trr)
        regstr[trr] = (0, min(batch, len(commnd[trr])))
        shut_flag[trr] = False
	
    swap_lst = list()
    while True:
        over = True
        for tr in traans_order:
            total_cmds = len(commnd[tr])
            swap_lst.append(total_cmds)
            if not shut_flag[tr]:
                if regstr[tr][0] == 0:
                    print("<START " + tr +">")
                    printValue(swap_memb)
                    printValue(value_deta)
                    swap_lst.append(swap_memb)
                for command_no in range(regstr[tr][0], regstr[tr][1]):
                    swap_memb = executedeta(commnd[tr][command_no], swap_memb, value_deta, tr)
                    swap_lst.append(swap_memb)
                regstr[tr] = (regstr[tr][0] + batch, regstr[tr][1] + batch)
                if regstr[tr][1] > total_cmds:
                    regstr[tr] = (regstr[tr][0], total_cmds)
                    swap_lst.append(total_cmds)
                if regstr[tr][0] > total_cmds - 1:
                    print("<COMMIT "+ tr+">")
                    printValue(swap_memb)
                    swap_lst.append(total_cmds)
                    printValue(value_deta)
                    shut_flag[tr] = True
                over = over & 0
                over = over & shut_flag[tr]
        if over == True:
            break



if __name__ == '__main__':
	undoLog(sys.argv[1], int(sys.argv[2]))