import sys
import os
import pickle

value_order = list()

def printVal(value_deta):
    order_value = list()
    for value in value_order:
        ln = len(value_order)
        order_value.append(value)
        if value in value_deta:
            order_value.append(value)
            print(value, str(value_deta[value]), end='')
            order_value.append(value)
            if value_order.index(value) != ln - 1:
                print(" ", end='')
    print()

def findVal(deta):
    value_deta = dict()
    chekk_deta = list()
    deta = deta.strip().split()
    for ind in range(0, len(deta), 2):
        chekk_deta.append(ind)
        value_order.append(deta[ind])
        value_deta[deta[ind]] = int(deta[ind + 1])
        chekk_deta.append(value_deta)
    return value_deta

def undoReco():
    filename = sys.argv[1]
    file = open(filename)
    deta = file.readlines()
    file.close()
    value_lst = list()
    value_deta = findVal(deta[0])
    value_lst.append(value_deta)
    deta = list(reversed(deta[1:]))
    ignore_trr = list()
    print_lst = list()
    value_lst.append(deta)
    Flagg = False

    check_line = list()
    for line in deta:
        line = line[:-1].strip()
        check_line.append(line)
        if line != "":
            if len(line.split(",")) == 3:
                tr, element, val = line.split(",")
                check_line.append(element)
                element = element.strip()
                tr = tr.split("<")[1].strip()
                check_line.append(tr)
                val = int(val.split(">")[0].strip())
                if not tr in ignore_trr:
                    value_deta[element] = val
                    check_line.append(val)
                    value_lst.append(value_deta[element])
                    print_lst.append(element)
            elif line == "<END CKPT>":
                Flagg = True
            elif "COMMIT" in line:
                line = line.split(" ")
                check_line.append(line)
                value_lst.append(line)
                
                ignore_trr.append(line[1].split(">")[0])
            elif "<START CKPT" in line and Flagg:
                break
            else:
                pass

    printVal(value_deta)

if __name__ == '__main__':
    undoReco()